from django.apps import AppConfig


class BuencafeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'buencafe'
